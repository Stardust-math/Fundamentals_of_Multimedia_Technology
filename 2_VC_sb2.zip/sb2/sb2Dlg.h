// sb2Dlg.h : header file
//
#include "mmsystem.h"

#if !defined(AFX_SB2DLG_H__7F004E97_A704_11D2_9FFC_0080C8E7148D__INCLUDED_)
#define AFX_SB2DLG_H__7F004E97_A704_11D2_9FFC_0080C8E7148D__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

/////////////////////////////////////////////////////////////////////////////
// CSb2Dlg dialog

class CSb2Dlg : public CDialog
{
// Construction
public:
	CSb2Dlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CSb2Dlg)
	enum { IDD = IDD_SB2_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSb2Dlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CSb2Dlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnButton1();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP();

private:
	HANDLE m_OpenWaveFile(CString FileNameAndPath);
	bool m_WaveOut();
	PCMWAVEFORMAT PCMWaveFmtRecord;
	WAVEHDR WaveHeader;
	//HWAVEOUT

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SB2DLG_H__7F004E97_A704_11D2_9FFC_0080C8E7148D__INCLUDED_)

// sb2Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "sb2.h"
#include "sb2Dlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSb2Dlg dialog


CSb2Dlg::CSb2Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSb2Dlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSb2Dlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CSb2Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSb2Dlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSb2Dlg, CDialog)
	//{{AFX_MSG_MAP(CSb2Dlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSb2Dlg message handlers

BOOL CSb2Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSb2Dlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CSb2Dlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

/*
	HANDLE m_OpenWaveFile(CString FileNameAndPath);
	bool m_WaveOut();
	PCMWAVEFORMAT PCMWaveFmtRecord;
	WAVEHDR WaveHeader;
*/

HANDLE CSb2Dlg::m_OpenWaveFile(CString FileNameAndPath)
{
	MMCKINFO MMCkInfoParent;
	MMCKINFO MMCkInfoChild;
	
	HMMIO hmmio = mmioOpen(FileNameAndPath.GetBuffer(80),NULL,MMIO_READ);
	if(!hmmio){
		AfxMessageBox("mmioOpen error",MB_OK,NULL);
		return (NULL);
	}

	MMCkInfoParent.fccType = mmioFOURCC('W','A','V','E');
	int errorCode = mmioDescend(hmmio,&MMCkInfoParent,NULL,MMIO_FINDRIFF);
	if(errorCode){
		AfxMessageBox("mmioDescend error",MB_OK|MB_ICONSTOP,NULL);
		mmioClose(hmmio,0);
		return (NULL);
	}

	MMCkInfoChild.ckid = mmioFOURCC('f','m','t',' ');
	errorCode = mmioDescend(hmmio,&MMCkInfoChild,&MMCkInfoParent,MMIO_FINDCHUNK);
	if(errorCode){
		AfxMessageBox("mmioDescend Child error",MB_OK|MB_ICONSTOP,NULL);
		mmioClose(hmmio,0);
		return (NULL);
	}

	DWORD bytesRead = mmioRead(hmmio,(LPSTR)&PCMWaveFmtRecord,MMCkInfoChild.cksize);
	if(bytesRead <= 0){
		AfxMessageBox("mmioRead error",MB_OK|MB_ICONSTOP,NULL);
		mmioClose(hmmio,0);
		return (NULL);
	}

	HWAVEOUT hWaveOut;
	errorCode = waveOutOpen(
		&hWaveOut,
		WAVE_MAPPER,
		(WAVEFORMATEX*)&PCMWaveFmtRecord,
		0l,
		0l,
		WAVE_FORMAT_QUERY);
	if(errorCode){
		AfxMessageBox("Incompatible WAVE format",MB_OK|MB_ICONSTOP,NULL);
		mmioClose(hmmio,0);
		return (NULL);
	}

	errorCode = mmioAscend(hmmio,&MMCkInfoChild,0);
	if(errorCode){
		AfxMessageBox("mmioAescend Child error",MB_OK|MB_ICONSTOP,NULL);
		mmioClose(hmmio,0);
		return (NULL);
	}

	MMCkInfoChild.ckid = mmioFOURCC('d','a','t','a');
	errorCode = mmioDescend(hmmio,&MMCkInfoChild,&MMCkInfoParent,MMIO_FINDCHUNK);
	if(errorCode){
		AfxMessageBox("mmioDescend Child error",MB_OK|MB_ICONSTOP,NULL);
		mmioClose(hmmio,0);
		return (NULL);
	}

	long lDataSize = MMCkInfoChild.cksize;
	HANDLE waveDataBlock = ::GlobalAlloc(GMEM_MOVEABLE,lDataSize);
	if(waveDataBlock == NULL){
		AfxMessageBox("error alloc mem",MB_OK|MB_ICONSTOP,NULL);
		mmioClose(hmmio,0);
		return (NULL);
	}

	LPBYTE pWave = (LPBYTE)::GlobalLock(waveDataBlock);

	if(mmioRead(hmmio,(LPSTR)pWave,lDataSize) != lDataSize){
		AfxMessageBox("error reading data",MB_OK|MB_ICONSTOP,NULL);
		mmioClose(hmmio,0);
		::GlobalFree(waveDataBlock);
		return (NULL);
	}

	WaveHeader.lpData = (LPSTR)pWave;
	WaveHeader.dwBufferLength = lDataSize;
	WaveHeader.dwFlags = 0L;
	WaveHeader.dwLoops = 0L;

	mmioClose(hmmio,0);
	return waveDataBlock;

}

bool CSb2Dlg::m_WaveOut()
{

	HWAVEOUT hWaveOut;
//	HANDLE hWaveOut;
	MMRESULT ReturnCode = waveOutOpen(
		&hWaveOut,
		WAVE_MAPPER,
		(WAVEFORMATEX*)&PCMWaveFmtRecord,
		0l,
		0l,
		0l);
	if(ReturnCode){
		AfxMessageBox("error open WAVE device",MB_OK|MB_ICONSTOP,NULL);
		return (false);
	}

	ReturnCode = waveOutPrepareHeader(
		hWaveOut,
		&WaveHeader,
		sizeof(WaveHeader));
	if(ReturnCode){
		AfxMessageBox("eror prepare header",MB_OK|MB_ICONSTOP,NULL);
		waveOutClose(hWaveOut);
		return (false);
	}

	ReturnCode = waveOutWrite(
		hWaveOut,
		&WaveHeader,
		sizeof(WaveHeader));
	if(ReturnCode){
		AfxMessageBox("eror write",MB_OK|MB_ICONSTOP,NULL);
		waveOutClose(hWaveOut);
		return (false);
	}

	do{}
	while(!(WaveHeader.dwFlags & WHDR_DONE));

	ReturnCode = waveOutUnprepareHeader(hWaveOut,
		&WaveHeader,
		sizeof(WaveHeader));
	if(ReturnCode){
		AfxMessageBox("eror unprepare header",MB_OK|MB_ICONSTOP,NULL);
		waveOutClose(hWaveOut);
		return (false);
	}

	WaveHeader.dwFlags = 0l;
	ReturnCode = waveOutClose(hWaveOut);
	if(ReturnCode){
		AfxMessageBox("eror close wave device",MB_OK|MB_ICONSTOP,NULL);
		waveOutClose(hWaveOut);
		return (false);
	}
	return (TRUE);
}

void CSb2Dlg::OnButton1() 
{
	HANDLE handle = m_OpenWaveFile("c:\\win98\\media\\The Microsoft Sound.wav");	
	if (handle){
		if (!m_WaveOut())
			AfxMessageBox("Could not play",MB_OK,NULL);
	}
	else
		AfxMessageBox("Could not play",MB_OK,NULL);

	if(::GlobalFree(handle))
			AfxMessageBox("Error Free Mem",MB_OK,NULL);
}

//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by VideoSample.rc
//
#define IDD_VIDEOSAMPLE_DIALOG          102
#define IDR_MAINFRAME                   128
#define IDC_BeginCap                    1000
#define IDC_GrabFrame                   1001
#define IDC_CapSetup                    1002
#define IDC_SaveFrame                   1003
#define IDC_SaveCapFile                 1004
#define IDC_SetupVideoFormat            1005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

// VideoSampleDlg.h : header file
//

#if !defined(AFX_VIDEOSAMPLEDLG_H__97B28337_60CD_11D3_A4C2_0080C8E72701__INCLUDED_)
#define AFX_VIDEOSAMPLEDLG_H__97B28337_60CD_11D3_A4C2_0080C8E72701__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

/////////////////////////////////////////////////////////////////////////////
// CVideoSampleDlg dialog

class CVideoSampleDlg : public CDialog
{
// Construction
public:
	CVideoSampleDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CVideoSampleDlg)
	enum { IDD = IDD_VIDEOSAMPLE_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CVideoSampleDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;
	HWND m_hCapture;


	// Generated message map functions
	//{{AFX_MSG(CVideoSampleDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	virtual void OnCancel();
	afx_msg void OnBeginCap();
	afx_msg void OnGrabFrame();
	afx_msg void OnSaveFrame();
	afx_msg void OnSaveCapFile();
	afx_msg void OnSetupVideoFormat();
	afx_msg void OnCapSetup();
	afx_msg void OnMove(int x, int y);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_VIDEOSAMPLEDLG_H__97B28337_60CD_11D3_A4C2_0080C8E72701__INCLUDED_)
